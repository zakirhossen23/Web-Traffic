

<?php $__env->startSection('title', 'Buy Credits'); ?>

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-10">
                    <div class="card">
                        <div class="card-header">Buy Credits</div>
                        <table class="card-table table">
                            <tbody>
                            <?php foreach($credits as $data): ?>
                                <tr>
                                    <td class="pl-4 pt-3"><strong><?php echo e($data->name); ?></strong> credits</td>
                                    <td class="text-left pt-3">$<?php echo e($data->price); ?> USD</td>
                                    <td class="text-center">
                                        <form class="w3-container w3-display-middle w3-card-4 " method="POST" id="payment-form"  action="<?php echo e(route('paypal')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="item_name" value="<?php echo e($data->name); ?>">
                                            <input type="hidden" name="item_number" value="<?php echo e($data->credits); ?>">
                                            <input type="hidden" name="amount" value="<?php echo e($data->price); ?>"> 
                                            <button class="btn btn-success btn-block">Buy</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>