<?php $__env->startSection('content'); ?>
    <h2>1. Pre-Installation</h2>

    <div class="box">
        <p>Please make sure the PHP extensions listed below are installed.</p>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Extensions</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($requirement->checkSystemCompatibility() as $key => $value): ?>
                        <?php if($value["type"] == "extension"): ?>
                        <tr>
                            <td><?php echo e($value["name"]); ?></td>

                            <td class="text-center">
                                <i class="fa fa-<?php echo e($value['check'] ? 'check' : 'times'); ?>" aria-hidden="true"></i>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="box">
        <p>Please make sure you have set the correct permissions for the directories listed below.</p>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Directories</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($requirement->checkSystemCompatibility() as $key => $value): ?>
                        <?php if($value["type"] == "directory"): ?>
                        <<tr>
                            <td><?php echo e($value["name"]); ?></td>

                            <td class="text-center">
                                <i class="fa fa-<?php echo e($value['check'] ? 'check' : 'times'); ?>" aria-hidden="true"></i>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="content-buttons clearfix">
        <a href="<?php echo e($requirement->satisfied() ? url('install/configuration') : '#'); ?>" class="btn btn-primary pull-right" <?php echo e($requirement->satisfied() ? '' : 'disabled'); ?>>
            Continue
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('install.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>