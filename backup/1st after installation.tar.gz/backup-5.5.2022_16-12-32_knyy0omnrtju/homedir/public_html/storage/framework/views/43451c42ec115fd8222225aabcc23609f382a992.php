

<?php $__env->startSection('title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-3">
                    <div class="card mb-3">
                        <h5 class="card-header">Settings</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="/settings/account">Account</a></li>
                            <li class="list-group-item"><a href="/settings/billing">Billing</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-12 col-lg-9">
                    <div class="card mb-3">
                        <h5 class="card-header">Account</h5>
                        <div class="card-body">
                        <form role="form" method="POST" action="<?php echo e(url('/settings/account')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <?php if(Session::has('success_msg')): ?>
                                <p class="alert alert-success"><?php echo e(Session::get('success_msg')); ?></p>
                            <?php endif; ?>
                            <?php if(Session::has('error_msg')): ?>
                                <p class="alert alert-danger"><?php echo e(Session::get('error_msg')); ?></p>
                            <?php endif; ?>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" value="<?php echo e(Auth::user()->email); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="form-text invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('curpass') ? ' has-error' : ''); ?>">
                                <label for="curpass">Current Password</label>
                                <input type="password" class="form-control" id="curpass" name="curpass" value="">
                                <?php if($errors->has('curpass')): ?>
                                    <span class="form-text invalid-feedback">
                                        <strong><?php echo e($errors->first('curpass')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="newpass">New Password</label>
                                <input type="password" class="form-control <?php echo e($errors->has('newpass') ? ' is-invalid' : ''); ?>" id="newpass" name="newpass" value="">
                                <?php if($errors->has('newpass')): ?>
                                    <span class="form-text invalid-feedback">
                                        <strong><?php echo e($errors->first('newpass')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Save Changes</button>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>