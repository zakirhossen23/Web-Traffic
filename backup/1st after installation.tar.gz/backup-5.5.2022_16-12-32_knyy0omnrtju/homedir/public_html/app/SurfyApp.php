<?php

namespace App;

class SurfyApp
{
    /**
     * The SurfyApp version.
     *
     * @var string
     */
    const VERSION = '1.0.0';
}
